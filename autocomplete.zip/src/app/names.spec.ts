import { Names } from './names';

describe('Names', () => {
  it('should create an instance', () => {
    expect(new Names()).toBeTruthy();
  });
});
