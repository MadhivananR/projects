import { Component,OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { debounceTime, map, Observable, startWith } from 'rxjs';
import { Names } from './names';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
  title = 'autoComplete';
  // options: string[] = ['One', 'Two', 'Three'];


  myControl = new FormControl();
  names!:Names[]
  filteredOptions=new  Observable<Names[]>;

constructor(private http:ServiceService){
  console.log(this.filteredOptions)

}

ngOnInit(){



  }

  getNames(value:any){
    this.http.getData(value).subscribe((res)=>{
      this.names=res;
      this.filteredOptions=this.myControl.valueChanges.pipe(
   
        startWith(''),
        map(value => this._filter(value))
        
      )
      
    })

}
 

  private _filter(value: string): Names[] {
    const filterValue = value.toLowerCase();

    return this.names.filter(option => option.name.toLowerCase().includes(filterValue));
  }
  
  
}

